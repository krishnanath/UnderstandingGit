module.exports = {
  jwtSecret: process.env.JWT_SECRET || '7d19fa6f-631f-4bba-aefa-87118622f5d5'
};